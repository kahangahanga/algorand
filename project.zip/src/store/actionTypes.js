export const SET_FLAG = 'SET_FLAG';
export const SET_MODEL = 'SET_MODEL';